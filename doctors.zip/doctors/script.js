const sidebar = document.querySelector('.sidebar')
const sidebarClose = document.querySelector('#sidebar-close')
const sidebarOpen = document.querySelector('#sidebar-open')
const menu = document.querySelector('.menu-content')
const menuItems = document.querySelectorAll('.submenu-item')
const subMenuTitles = document.querySelectorAll('.submenu .menu-title')

console.log(sidebarOpen)
sidebarClose.addEventListener('click', () => {
  sidebar.classList.add('full-sidebar')

  menu.classList.add('full')
})
sidebarOpen.addEventListener('click', () => {
  sidebar.classList.remove('full-sidebar')

  menu.classList.remove('full')
})
// menuItems.forEach((item, index) => {
//   item.addEventListener('click', () => {
//     menu.classList.add('submenu-active')
//     item.classList.add('show-submenu')
//     menuItems.forEach((item2, index2) => {
//       if (index !== index2) {
//         item2.classList.remove('show-submenu')
//       }
//     })
//   })
// })

// subMenuTitles.forEach((title) => {
//   title.addEventListener('click', () => {
//     menu.classList.remove('submenu-active')
//   })
// })

// console.log(menuItems, subMenuTitles)
